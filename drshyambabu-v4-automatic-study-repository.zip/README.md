# V4 Automatic Study Repository
Scans the entire public GitHub repository tree and automatically finds PDFs under `study-material/<subject>/`.
Example: `study-material/physics/your-note.pdf`
Upload/commit a PDF; refresh the website. No HTML edit is needed.